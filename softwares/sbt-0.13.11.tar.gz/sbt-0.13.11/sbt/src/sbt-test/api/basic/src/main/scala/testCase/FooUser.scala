package testCase

case class FooUser(@Foo a: Int)
