
import annotation.target.field


package object testCase {
	type Foo = JFoo @field;
}
