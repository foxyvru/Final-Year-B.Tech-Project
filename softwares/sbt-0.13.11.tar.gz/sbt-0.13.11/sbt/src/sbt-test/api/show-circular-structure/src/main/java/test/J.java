package test;

public class J {
  public static final class J2 extends J { }
  public static final class J3 extends J { }
}
