package test3

trait B extends A
