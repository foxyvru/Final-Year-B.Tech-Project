class B {
	def foo(a: A): Boolean = a.initialized
}
