trait badScala {
  def foo: Int = false
}