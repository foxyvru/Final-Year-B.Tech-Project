object UseMaven
{
	def y = PublishedMaven.x
}