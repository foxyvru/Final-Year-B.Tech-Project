public final class Def {
	public static final int x = 3;
}

