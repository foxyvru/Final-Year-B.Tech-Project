package pkg;
/** This is class K */
public class K {
}