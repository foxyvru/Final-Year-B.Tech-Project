public class hasstaticfinal {
    // the `TYPE` and `VALUE` strings are replaced with various values during tests
    public static final TYPE HELLO = VALUE;
}
