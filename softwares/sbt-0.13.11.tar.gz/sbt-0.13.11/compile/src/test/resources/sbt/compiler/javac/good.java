

public class good {
    public static String test() {
        return "Hello";
    }
}