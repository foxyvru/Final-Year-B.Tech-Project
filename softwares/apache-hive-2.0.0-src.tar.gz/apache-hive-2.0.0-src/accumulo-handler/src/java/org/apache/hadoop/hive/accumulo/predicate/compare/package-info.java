/**
 * PrimitiveCompare and CompareOpt implementations for use in PrimitiveComparisonFilter iterator
 */
package org.apache.hadoop.hive.accumulo.predicate.compare;