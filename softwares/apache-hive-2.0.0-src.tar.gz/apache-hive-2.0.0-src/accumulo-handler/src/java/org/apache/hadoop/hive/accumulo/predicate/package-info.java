/**
 * Predicate pushdown to Accumulo filter iterators.
 */
package org.apache.hadoop.hive.accumulo.predicate;