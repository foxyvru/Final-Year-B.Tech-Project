create table tbl_created_by_init(i int);
