See http://wiki.apache.org/hadoop/Hive/HBaseIntegration for
information about the HBase storage handler.
